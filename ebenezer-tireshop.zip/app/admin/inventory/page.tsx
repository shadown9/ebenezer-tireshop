"use client"

import { useState } from "react"
import { AdminHeader } from "@/components/admin-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  useTires,
  updateTire,
  addTire as addTireToFirebase,
  deleteTire as deleteTireFromFirebase,
} from "@/lib/firebase-hooks"
import { Plus, Minus, Search, AlertTriangle, Edit, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Tire, TireCondition } from "@/lib/types"
import { notificationHelpers } from "@/lib/notification-system"

export default function InventoryPage() {
  const { tires, loading } = useTires()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [conditionFilter, setConditionFilter] = useState<"all" | "New" | "Used">("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingTire, setEditingTire] = useState<Tire | null>(null)

  const [newTire, setNewTire] = useState<Omit<Tire, "id">>({
    brand: "",
    width: 205,
    ratio: 55,
    diameter: 16,
    condition: "New",
    quantity: 0,
    price: 0,
    image: "",
  })

  const filteredTires = tires.filter((tire) => {
    const matchesSearch =
      tire.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `${tire.width}/${tire.ratio}R${tire.diameter}`.includes(searchTerm)

    const matchesCondition = conditionFilter === "all" || tire.condition === conditionFilter

    return matchesSearch && matchesCondition
  })

  const lowStockCount = tires.filter((tire) => tire.quantity < 4).length

  const handleQuickSale = async (tireId: string) => {
    const tire = tires.find((t) => t.id === tireId)
    if (!tire) return

    const currentQuantity = tire.quantity
    if (currentQuantity > 0) {
      const newQuantity = currentQuantity - 1
      await updateTire(tireId, { quantity: newQuantity })

      if (newQuantity < 4) {
        notificationHelpers.lowInventory(
          tire.id,
          `${tire.brand} ${tire.width}/${tire.ratio}R${tire.diameter}`,
          newQuantity,
        )
      }

      toast({
        title: "Quick Sale",
        description: "Quantity decreased by 1",
      })
    } else {
      toast({
        title: "Out of Stock",
        description: "Cannot decrease quantity below 0",
        variant: "destructive",
      })
    }
  }

  const handleAddStock = async (tireId: string, currentQuantity: number) => {
    await updateTire(tireId, { quantity: currentQuantity + 1 })
    toast({
      title: "Stock Added",
      description: "Quantity increased by 1",
    })
  }

  const handleAddNewTire = async () => {
    if (!newTire.brand || newTire.price <= 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    await addTireToFirebase(newTire)
    setIsAddDialogOpen(false)
    setNewTire({
      brand: "",
      width: 205,
      ratio: 55,
      diameter: 16,
      condition: "New",
      quantity: 0,
      price: 0,
      image: "",
    })

    toast({
      title: "Tire Added",
      description: "New tire has been added to inventory",
    })
  }

  const handleEditTire = async () => {
    if (!editingTire || !editingTire.brand || editingTire.price <= 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    const { id, ...updates } = editingTire
    await updateTire(id, updates)

    setIsEditDialogOpen(false)
    setEditingTire(null)

    toast({
      title: "Tire Updated",
      description: "Tire information has been updated",
    })
  }

  const handleDeleteTire = async (tireId: string, brand: string) => {
    if (confirm(`Are you sure you want to delete ${brand}? This action cannot be undone.`)) {
      await deleteTireFromFirebase(tireId)
      toast({
        title: "Tire Deleted",
        description: "Tire has been removed from inventory",
      })
    }
  }

  const handleImageUpload = (file: File, isEdit = false) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      const base64String = reader.result as string
      if (isEdit && editingTire) {
        setEditingTire({ ...editingTire, image: base64String })
      } else {
        setNewTire({ ...newTire, image: base64String })
      }
      toast({
        title: "Image Uploaded",
        description: "Image has been added successfully",
      })
    }
    reader.onerror = () => {
      toast({
        title: "Upload Failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      })
    }
    reader.readAsDataURL(file)
  }

  if (loading) {
    return (
      <div className="min-h-screen p-4 sm:p-6 lg:p-8 pt-16 lg:pt-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">Loading inventory...</div>
        </div>
      </div>
    )
  }

  return (
    <div>
      <AdminHeader title="Inventario" description="Manage your tire inventory and stock levels" />

      <div className="p-4 sm:p-6">
        {/* Alert Banner for Low Stock */}
        {lowStockCount > 0 && (
          <Card className="p-4 mb-6 border-destructive/50 bg-destructive/5">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <div>
                <p className="font-semibold text-foreground">Low Stock Alert</p>
                <p className="text-sm text-muted-foreground">
                  {lowStockCount} tire model{lowStockCount !== 1 ? "s" : ""} below minimum stock level (4 units)
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Search and Actions */}
        <div className="flex flex-col gap-3 sm:gap-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by brand or size (e.g., 205/55R16)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={conditionFilter} onValueChange={(value: any) => setConditionFilter(value)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Conditions</SelectItem>
                <SelectItem value="New">New Only</SelectItem>
                <SelectItem value="Used">Used Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => setIsAddDialogOpen(true)} className="w-full sm:w-auto whitespace-nowrap">
            <Plus className="mr-2 h-4 w-4" />
            Add New Tire
          </Button>
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Tire</DialogTitle>
              <DialogDescription>Enter the details for the new tire to add to inventory</DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
              <div className="space-y-2 col-span-full">
                <Label htmlFor="image-upload">Tire Image</Label>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Input
                      id="image-upload"
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          handleImageUpload(file, false)
                        }
                      }}
                      className="flex-1"
                    />
                  </div>
                  {newTire.image && (
                    <div className="relative h-32 w-32 rounded border overflow-hidden bg-muted">
                      <Image
                        src={newTire.image || "/placeholder.svg?height=48&width=48&query=tire"}
                        alt="Preview"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground">Upload an image of the tire</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="brand">Brand</Label>
                <Input
                  id="brand"
                  value={newTire.brand}
                  onChange={(e) => setNewTire({ ...newTire, brand: e.target.value })}
                  placeholder="Michelin, Goodyear, etc."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="condition">Condition</Label>
                <Select
                  value={newTire.condition}
                  onValueChange={(val) => setNewTire({ ...newTire, condition: val as TireCondition })}
                >
                  <SelectTrigger id="condition">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="New">New</SelectItem>
                    <SelectItem value="Used">Used</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="width">Width</Label>
                <Input
                  id="width"
                  type="number"
                  value={newTire.width.toString()}
                  onChange={(e) => setNewTire({ ...newTire, width: Number.parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ratio">Ratio</Label>
                <Input
                  id="ratio"
                  type="number"
                  value={newTire.ratio.toString()}
                  onChange={(e) => setNewTire({ ...newTire, ratio: Number.parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="diameter">Diameter</Label>
                <Input
                  id="diameter"
                  type="number"
                  value={newTire.diameter.toString()}
                  onChange={(e) => setNewTire({ ...newTire, diameter: Number.parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={newTire.quantity.toString()}
                  onChange={(e) => setNewTire({ ...newTire, quantity: Number.parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Price ($)</Label>
                <Input
                  id="price"
                  type="number"
                  value={newTire.price.toString()}
                  onChange={(e) => setNewTire({ ...newTire, price: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddNewTire}>Add Tire</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Tire</DialogTitle>
              <DialogDescription>Update the tire information</DialogDescription>
            </DialogHeader>

            {editingTire && (
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="edit-image-upload">Tire Image</Label>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Input
                        id="edit-image-upload"
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) {
                            handleImageUpload(file, true)
                          }
                        }}
                        className="flex-1"
                      />
                    </div>
                    {editingTire.image && (
                      <div className="relative h-32 w-32 rounded border overflow-hidden bg-muted">
                        <Image
                          src={editingTire.image || "/placeholder.svg?height=48&width=48&query=tire"}
                          alt="Preview"
                          fill
                          className="object-cover"
                        />
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground">Upload a new image to replace the current one</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-brand">Brand</Label>
                  <Input
                    id="edit-brand"
                    value={editingTire.brand}
                    onChange={(e) => setEditingTire({ ...editingTire, brand: e.target.value })}
                    placeholder="Michelin, Goodyear, etc."
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-condition">Condition</Label>
                  <Select
                    value={editingTire.condition}
                    onValueChange={(val) => setEditingTire({ ...editingTire, condition: val as TireCondition })}
                  >
                    <SelectTrigger id="edit-condition">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="New">New</SelectItem>
                      <SelectItem value="Used">Used</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-width">Width</Label>
                  <Input
                    id="edit-width"
                    type="number"
                    value={editingTire.width.toString()}
                    onChange={(e) => setEditingTire({ ...editingTire, width: Number.parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-ratio">Ratio</Label>
                  <Input
                    id="edit-ratio"
                    type="number"
                    value={editingTire.ratio.toString()}
                    onChange={(e) => setEditingTire({ ...editingTire, ratio: Number.parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-diameter">Diameter</Label>
                  <Input
                    id="edit-diameter"
                    type="number"
                    value={editingTire.diameter.toString()}
                    onChange={(e) => setEditingTire({ ...editingTire, diameter: Number.parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-quantity">Quantity</Label>
                  <Input
                    id="edit-quantity"
                    type="number"
                    value={editingTire.quantity.toString()}
                    onChange={(e) => setEditingTire({ ...editingTire, quantity: Number.parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-price">Price ($)</Label>
                  <Input
                    id="edit-price"
                    type="number"
                    value={editingTire.price.toString()}
                    onChange={(e) => setEditingTire({ ...editingTire, price: Number.parseFloat(e.target.value) || 0 })}
                  />
                </div>
              </div>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleEditTire}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Inventory Table */}
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16 sm:w-20">Image</TableHead>
                  <TableHead className="min-w-[120px]">Brand</TableHead>
                  <TableHead className="min-w-[100px]">Size</TableHead>
                  <TableHead className="min-w-[90px]">Condition</TableHead>
                  <TableHead className="text-right min-w-[80px]">Quantity</TableHead>
                  <TableHead className="text-right min-w-[70px]">Price</TableHead>
                  <TableHead className="text-right min-w-[180px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTires.map((tire) => {
                  const isLowStock = tire.quantity < 4

                  return (
                    <TableRow
                      key={tire.id}
                      className={isLowStock ? "bg-destructive/5 border-l-4 border-l-destructive" : ""}
                    >
                      <TableCell>
                        <div className="relative h-12 w-12 rounded overflow-hidden bg-muted">
                          <Image
                            src={tire.image || "/placeholder.svg?height=48&width=48&query=tire"}
                            alt={tire.brand}
                            fill
                            className="object-cover"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-foreground">{tire.brand}</TableCell>
                      <TableCell className="font-mono text-sm text-foreground">{`${tire.width}/${tire.ratio}R${tire.diameter}`}</TableCell>
                      <TableCell>
                        <Badge variant={tire.condition === "New" ? "default" : "secondary"} className="capitalize">
                          {tire.condition}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {isLowStock && <AlertTriangle className="h-3 w-3 text-destructive flex-shrink-0" />}
                          <span className={`font-medium ${isLowStock ? "text-destructive" : "text-foreground"}`}>
                            {tire.quantity}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-medium text-foreground">${tire.price}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-transparent"
                            onClick={() => handleAddStock(tire.id, tire.quantity)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-transparent"
                            onClick={() => handleQuickSale(tire.id)}
                            disabled={tire.quantity === 0}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-transparent"
                            onClick={() => {
                              setEditingTire(tire)
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:bg-destructive hover:text-destructive-foreground bg-transparent"
                            onClick={() => handleDeleteTire(tire.id, tire.brand)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {filteredTires.length === 0 && (
            <div className="p-8 text-center text-muted-foreground">
              <p>No tires found matching your search.</p>
            </div>
          )}
        </Card>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          <Card className="p-4">
            <CardHeader>
              <CardTitle>Total Models</CardTitle>
              <CardDescription>{tires.length}</CardDescription>
            </CardHeader>
          </Card>
          <Card className="p-4">
            <CardHeader>
              <CardTitle>Total Units</CardTitle>
              <CardDescription>{tires.reduce((sum, tire) => sum + tire.quantity, 0)}</CardDescription>
            </CardHeader>
          </Card>
          <Card className="p-4">
            <CardHeader>
              <CardTitle>Low Stock Items</CardTitle>
              <CardDescription className="text-destructive">{lowStockCount}</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    </div>
  )
}
