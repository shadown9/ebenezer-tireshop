import { neon } from "@neondatabase/serverless"
import { type NextRequest, NextResponse } from "next/server"

const sql = neon(process.env.DATABASE_URL || "")

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await sql("DELETE FROM sales WHERE id = $1", [params.id])
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("[v0] DELETE /api/sales/[id] error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
