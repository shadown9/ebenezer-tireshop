import type { User } from "./types"

export async function login(usernameOrEmail: string, password: string): Promise<{ user: User; token: string } | null> {
  console.log("[v0] Client login attempt with:", usernameOrEmail)

  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: usernameOrEmail, password }),
    })

    if (!response.ok) {
      console.log("[v0] Login failed:", response.status, response.statusText)
      return null
    }

    const result = await response.json()
    console.log("[v0] Login successful")
    return result
  } catch (error) {
    console.error("[v0] Login error:", error)
    return null
  }
}

export async function logout(token: string): Promise<void> {
  try {
    await fetch("/api/auth/logout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    })
  } catch (error) {
    console.error("[v0] Logout error:", error)
  }
}

export async function getCurrentUser(token: string): Promise<User | null> {
  try {
    const response = await fetch("/api/auth/current", {
      headers: { Authorization: `Bearer ${token}` },
    })

    if (!response.ok) {
      return null
    }

    const { user } = await response.json()
    return user
  } catch (error) {
    console.error("[v0] Get current user error:", error)
    return null
  }
}
