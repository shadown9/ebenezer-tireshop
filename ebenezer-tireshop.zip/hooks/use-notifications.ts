"use client"

import { useState, useEffect } from "react"
import { NotificationSystem } from "@/lib/notification-system"
import type { Notification } from "@/lib/types"

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [soundEnabled, setSoundEnabledState] = useState(false)
  const [pushEnabled, setPushEnabledState] = useState(false)
  const [browserPushEnabled, setBrowserPushEnabledState] = useState(false)
  const system = NotificationSystem.getInstance()

  useEffect(() => {
    console.log("[v0] useNotifications: Setting up subscriptions")

    const unsubscribe = system.subscribe((updatedNotifications) => {
      console.log("[v0] useNotifications: Received notification update, count:", updatedNotifications.length)
      const newUnreadCount = system.getUnreadCount()
      console.log("[v0] useNotifications: Unread count:", newUnreadCount)
      setNotifications(updatedNotifications)
      setUnreadCount(newUnreadCount)
    })

    const unsubscribePreferences = system.subscribeToPreferences((prefs) => {
      console.log("[v0] useNotifications: Received preferences update", prefs)
      setSoundEnabledState(prefs.soundEnabled)
      setPushEnabledState(prefs.pushEnabled)
      setBrowserPushEnabledState(prefs.browserPushEnabled)
    })

    return () => {
      unsubscribe()
      unsubscribePreferences()
    }
  }, [])

  return {
    notifications,
    unreadCount,
    markAsRead: (id: string) => {
      console.log("[v0] useNotifications: Marking as read:", id)
      system.markAsRead(id)
    },
    markAllAsRead: () => {
      console.log("[v0] useNotifications: Marking all as read")
      system.markAllAsRead()
    },
    deleteNotification: (id: string) => {
      console.log("[v0] useNotifications: Deleting notification:", id)
      system.delete(id)
    },
    deleteAll: () => {
      console.log("[v0] useNotifications: Deleting all notifications")
      system.deleteAll()
    },
    soundEnabled,
    pushEnabled,
    browserPushEnabled,
    setSoundEnabled: (enabled: boolean) => {
      console.log("[v0] useNotifications: Setting sound enabled:", enabled)
      system.setSoundEnabled(enabled)
    },
    setPushEnabled: (enabled: boolean) => {
      console.log("[v0] useNotifications: Setting push enabled:", enabled)
      system.setPushEnabled(enabled)
    },
    setBrowserPushEnabled: async (enabled: boolean) => {
      console.log("[v0] useNotifications: Setting browser push enabled:", enabled)
      const success = await system.setBrowserPushEnabled(enabled)
      console.log("[v0] useNotifications: Browser push result:", success)
      return success
    },
    getBrowserPermissionStatus: () => system.getBrowserPermissionStatus(),
  }
}
